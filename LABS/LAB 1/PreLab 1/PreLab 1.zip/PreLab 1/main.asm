/*
* PreLab1.asm
*
* Creado: 
* Autor : Jorge Puente
* Descripci�n: Contador binario de 4 bits usando 2 botones
*/
/****************************************/
// Encabezado (Definici�n de Registros, Variables y Constantes)
.include "M328PDEF.inc"     // Include definitions specific to ATMega328P
.dseg
.org    SRAM_START
//variable_name:     .byte   1   // Memory alocation for variable_name:     .byte   (byte size)

.cseg
.org 0x0000
 /****************************************/
RJMP RESET

/****************************************/
// Configuraci�n de la pila
RESET:
    LDI     R16, LOW(RAMEND)
    OUT     SPL, R16
    LDI     R16, HIGH(RAMEND)
    OUT     SPH, R16

/****************************************/
// Configuraci�n MCU
SETUP:
    //Botones
    CBI     DDRD, 2          // PD2 entrada
    CBI     DDRD, 3          // PD3 entrada
    SBI     PORTD, 2         // Pull-up PD2
    SBI     PORTD, 3         // Pull-up PD3

    //Salidas
    LDI     R16, 0b00001111        //PB0�PB3 salida
    OUT     DDRB, R16

    //Empezar contador
    CLR     R17
    OUT     PORTB, R17       //Valor inicial

/****************************************/
// Loop Infinito
MAIN_LOOP:

    //Inc
    SBIS    PIND, 2
    RCALL   BTN_INC

    //Dec
    SBIS    PIND, 3
    RCALL   BTN_DEC

    RJMP    MAIN_LOOP

/****************************************/
// Boton Antirebote
BTN_INC:
    RCALL   DELAY
    SBIS    PIND, 2
    RJMP    INC_OK
    RET

INC_OK:
    INC     R17
    ANDI    R17, 0b00001111
    OUT     PORTB, R17 

EIS:
    SBIC    PIND, 2
    RJMP    EDS
    RET

/****************************************/
BTN_DEC:
    RCALL   DELAY
    SBIS    PIND, 3
    RJMP    DEC_OK
    RET

DEC_OK:
    DEC     R17
    ANDI    R17, 0b00001111
    OUT     PORTB, R17  

EDS:
    SBIC    PIND, 3
    RJMP    EDS
    RET

/****************************************/
//Delay
DELAY:
    LDI     R19, 2
D1:
    LDI     R20, 2
D2:
    DEC     R20
    BRNE    D2
    DEC     R19
    BRNE    D1
    RET
